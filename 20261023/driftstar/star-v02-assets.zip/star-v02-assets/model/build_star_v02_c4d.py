"""Cinema 4D: star v02 as a live, nondestructive setup.

Run in C4D 2024+ via Extensions > Script Manager (open this file, Execute). Keep it in the
same folder as star_v02.fbx if you also want the baked reference mesh merged in.

Builds, under one null "Star_v02_live":
  Volume Mesher
    Volume Builder (SDF, union, then an SDF Smooth filter = the soft fillets)
      Needle_Y_up, Needle_X, Needle_Z: each a Sweep of a 4-sided (diamond) profile along a
      straight line, with the Sweep's Scale curve (Details > Scale) giving the taper.
  Star_v02_baked (from FBX, hidden): the exact mesh the renders used, for reference.

Edit live: a Sweep's Scale curve (taper and point width), its profile radius (thickness at
the centre), the line's points (length), the SDF Smooth strength (fillet size), and the
Volume Builder voxel size (detail). Units are cm; the star is ~500 cm tall.

Written for Ravi's star; not yet run in C4D (the licence on Ravi's Mac had expired). Where a
parameter ID differs in your version, the script says what to set by hand.
"""
import json
import os

import c4d

P = json.loads(r"""{
 "needles": {
  "Needle_Y_up": {
   "axis": "Y",
   "len_neg": 3.11,
   "len_pos": 1.89,
   "w0": 0.2,
   "knots": [
    [
     0.0,
     0.3
    ],
    [
     0.0256,
     0.3001
    ],
    [
     0.0513,
     0.301
    ],
    [
     0.0769,
     0.3035
    ],
    [
     0.1026,
     0.3078
    ],
    [
     0.1282,
     0.3142
    ],
    [
     0.1538,
     0.3229
    ],
    [
     0.1795,
     0.3341
    ],
    [
     0.2051,
     0.348
    ],
    [
     0.2308,
     0.3647
    ],
    [
     0.2564,
     0.3844
    ],
    [
     0.2821,
     0.4073
    ],
    [
     0.3077,
     0.4334
    ],
    [
     0.3333,
     0.4628
    ],
    [
     0.359,
     0.4958
    ],
    [
     0.3846,
     0.5323
    ],
    [
     0.4103,
     0.5725
    ],
    [
     0.4359,
     0.6166
    ],
    [
     0.4615,
     0.6645
    ],
    [
     0.4872,
     0.7164
    ],
    [
     0.5128,
     0.7724
    ],
    [
     0.5385,
     0.8325
    ],
    [
     0.5641,
     0.8969
    ],
    [
     0.5897,
     0.9656
    ],
    [
     0.6154,
     1.0
    ],
    [
     0.641,
     1.0
    ],
    [
     0.6667,
     0.8943
    ],
    [
     0.6923,
     0.7927
    ],
    [
     0.7179,
     0.6994
    ],
    [
     0.7436,
     0.6145
    ],
    [
     0.7692,
     0.5379
    ],
    [
     0.7949,
     0.4698
    ],
    [
     0.8205,
     0.4099
    ],
    [
     0.8462,
     0.3585
    ],
    [
     0.8718,
     0.3154
    ],
    [
     0.8974,
     0.2807
    ],
    [
     0.9231,
     0.2544
    ],
    [
     0.9487,
     0.2364
    ],
    [
     0.9744,
     0.2268
    ],
    [
     1.0,
     0.225
    ]
   ]
  },
  "Needle_X": {
   "axis": "X",
   "len_neg": 1.78,
   "len_pos": 1.78,
   "w0": 0.2,
   "knots": [
    [
     0.0,
     0.24
    ],
    [
     0.0256,
     0.2405
    ],
    [
     0.0513,
     0.2452
    ],
    [
     0.0769,
     0.2546
    ],
    [
     0.1026,
     0.2687
    ],
    [
     0.1282,
     0.2876
    ],
    [
     0.1538,
     0.3112
    ],
    [
     0.1795,
     0.3397
    ],
    [
     0.2051,
     0.3728
    ],
    [
     0.2308,
     0.4107
    ],
    [
     0.2564,
     0.4534
    ],
    [
     0.2821,
     0.5008
    ],
    [
     0.3077,
     0.553
    ],
    [
     0.3333,
     0.61
    ],
    [
     0.359,
     0.6717
    ],
    [
     0.3846,
     0.7381
    ],
    [
     0.4103,
     0.8093
    ],
    [
     0.4359,
     0.8853
    ],
    [
     0.4615,
     0.966
    ],
    [
     0.4872,
     1.0
    ],
    [
     0.5128,
     1.0
    ],
    [
     0.5385,
     0.966
    ],
    [
     0.5641,
     0.8853
    ],
    [
     0.5897,
     0.8093
    ],
    [
     0.6154,
     0.7381
    ],
    [
     0.641,
     0.6717
    ],
    [
     0.6667,
     0.61
    ],
    [
     0.6923,
     0.553
    ],
    [
     0.7179,
     0.5008
    ],
    [
     0.7436,
     0.4534
    ],
    [
     0.7692,
     0.4107
    ],
    [
     0.7949,
     0.3728
    ],
    [
     0.8205,
     0.3397
    ],
    [
     0.8462,
     0.3112
    ],
    [
     0.8718,
     0.2876
    ],
    [
     0.8974,
     0.2687
    ],
    [
     0.9231,
     0.2546
    ],
    [
     0.9487,
     0.2452
    ],
    [
     0.9744,
     0.2405
    ],
    [
     1.0,
     0.24
    ]
   ]
  },
  "Needle_Z": {
   "axis": "Z",
   "len_neg": 1.78,
   "len_pos": 1.78,
   "w0": 0.2,
   "knots": [
    [
     0.0,
     0.24
    ],
    [
     0.0256,
     0.2405
    ],
    [
     0.0513,
     0.2452
    ],
    [
     0.0769,
     0.2546
    ],
    [
     0.1026,
     0.2687
    ],
    [
     0.1282,
     0.2876
    ],
    [
     0.1538,
     0.3112
    ],
    [
     0.1795,
     0.3397
    ],
    [
     0.2051,
     0.3728
    ],
    [
     0.2308,
     0.4107
    ],
    [
     0.2564,
     0.4534
    ],
    [
     0.2821,
     0.5008
    ],
    [
     0.3077,
     0.553
    ],
    [
     0.3333,
     0.61
    ],
    [
     0.359,
     0.6717
    ],
    [
     0.3846,
     0.7381
    ],
    [
     0.4103,
     0.8093
    ],
    [
     0.4359,
     0.8853
    ],
    [
     0.4615,
     0.966
    ],
    [
     0.4872,
     1.0
    ],
    [
     0.5128,
     1.0
    ],
    [
     0.5385,
     0.966
    ],
    [
     0.5641,
     0.8853
    ],
    [
     0.5897,
     0.8093
    ],
    [
     0.6154,
     0.7381
    ],
    [
     0.641,
     0.6717
    ],
    [
     0.6667,
     0.61
    ],
    [
     0.6923,
     0.553
    ],
    [
     0.7179,
     0.5008
    ],
    [
     0.7436,
     0.4534
    ],
    [
     0.7692,
     0.4107
    ],
    [
     0.7949,
     0.3728
    ],
    [
     0.8205,
     0.3397
    ],
    [
     0.8462,
     0.3112
    ],
    [
     0.8718,
     0.2876
    ],
    [
     0.8974,
     0.2687
    ],
    [
     0.9231,
     0.2546
    ],
    [
     0.9487,
     0.2452
    ],
    [
     0.9744,
     0.2405
    ],
    [
     1.0,
     0.24
    ]
   ]
  }
 },
 "fillet_cm": 30.0,
 "edge_cm": 1.6
}""")
HERE = os.path.dirname(__file__) if "__file__" in dir() else ""
S = 100.0  # m -> cm
AX = {"X": c4d.Vector(1, 0, 0), "Y": c4d.Vector(0, 1, 0), "Z": c4d.Vector(0, 0, 1)}
notes = []


def try_set(op, pid_name, value):
    pid = getattr(c4d, pid_name, None)
    if pid is None:
        notes.append(f"{op.GetName()}: set {pid_name} by hand")
        return False
    try:
        op[pid] = value
        return True
    except Exception:
        notes.append(f"{op.GetName()}: set {pid_name} by hand")
        return False


def needle(name, n):
    sw = c4d.BaseObject(c4d.Osweep)
    sw.SetName(name)
    prof = c4d.BaseObject(c4d.Osplinenside)
    prof.SetName(name + "_Diamond")
    prof[c4d.PRIM_NSIDE_SIDES] = 4
    prof[c4d.PRIM_NSIDE_RADIUS] = n["w0"] * S  # corner radius = the diamond's half-diagonal
    a = AX[n["axis"]]
    path = c4d.SplineObject(2, c4d.SPLINETYPE_LINEAR)
    path.SetName(name + "_Path")
    path.SetPoint(0, -a * n["len_neg"] * S)
    path.SetPoint(1, a * n["len_pos"] * S)
    path.Message(c4d.MSG_UPDATE)
    path.InsertUnder(sw)
    prof.InsertUnder(sw)  # the profile must be the first child: inserted last, it lands on top
    sd = c4d.SplineData()
    sd.MakeLinearSplineBezier(len(n["knots"]))
    for i, (t, s) in enumerate(n["knots"]):
        sd.SetKnot(i, c4d.Vector(t, s, 0), c4d.FLAG_KNOT_T_BREAK)
    try_set(sw, "SWEEPOBJECT_SPLINESCALE", sd)
    try_set(sw, "SWEEPOBJECT_CONSTANT", True)  # even cross-section along the rail
    return sw


def main():
    doc = c4d.documents.GetActiveDocument()
    doc.StartUndo()
    root = c4d.BaseObject(c4d.Onull)
    root.SetName("Star_v02_live")
    mesher = c4d.BaseObject(c4d.Ovolumemesher)
    mesher.SetName("Volume Mesher")
    vb = c4d.BaseObject(c4d.Ovolumebuilder)
    vb.SetName("Volume Builder")
    try_set(vb, "ID_VOLUMEBUILDER_VOLUMETYPE", 1)  # 1 = SDF
    try_set(vb, "ID_VOLUMEBUILDER_GRID_SIZE", 0.6)  # voxel size, cm: lower = finer
    sweeps = [needle(k, n) for k, n in P["needles"].items()]
    for sw in reversed(sweeps):
        sw.InsertUnder(vb)
    vb.InsertUnder(mesher)
    mesher.InsertUnder(root)
    doc.InsertObject(root)
    doc.AddUndo(c4d.UNDOTYPE_NEW, root)
    # Children of a Volume Builder join its list as Union. The fillets come from an SDF Smooth
    # filter above them; add it through the API where available, else by hand.
    try:
        sm = c4d.BaseObject(c4d.Osdfsmooth) if hasattr(c4d, "Osdfsmooth") else None
        if sm is not None:
            sm.SetName("SDF Smooth (fillets)")
            sm.InsertUnder(vb)
            try_set(sm, "ID_SDFFILTER_STRENGTH", 100.0)
            try_set(sm, "ID_SDFFILTER_ITERATIONS", 6)
            try_set(sm, "ID_SDFFILTER_VOXEL_DISTANCE", max(1, round(P["fillet_cm"] / 0.6 / 3)))
        else:
            notes.append("Volume Builder: add an SDF Smooth filter above the three sweeps (Filter > SDF Smooth), ~6 iterations")
    except Exception as e:
        notes.append(f"Volume Builder: add an SDF Smooth filter by hand ({e})")
    fbx = os.path.join(HERE, "star_v02.fbx")
    if HERE and os.path.exists(fbx):
        c4d.documents.MergeDocument(doc, fbx, c4d.SCENEFILTER_OBJECTS | c4d.SCENEFILTER_MATERIALS)
        ob = doc.GetFirstObject()
        while ob:
            if ob.GetName() == "Star_v02":  # the merged FBX mesh: keep it as a hidden reference
                ob.SetName("Star_v02_baked")
                ob[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = 1
                ob[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = 1
            ob = ob.GetNext()
    doc.EndUndo()
    c4d.EventAdd()
    if notes:
        c4d.gui.MessageDialog("Star built. A few settings need a hand:\n\n" + "\n".join(notes))


if __name__ == "__main__":
    main()
