# Star v02: three needles

Ravi's star, built as an object: three needles on X, Y and Z, each a diamond in section
(its corners point along the other two axes). Each needle keeps its full width through the
middle, curves in to a rounded point, and merges into the others with soft round fillets.
From the sketch camera (39° up, turned 45°) the needles read as the flat six-point star of
the drawing. Turn it and you see it is three bars crossing.

The vertical needle runs 1.89 m up and 3.11 m down. Each side needle runs 1.78 m each way.
In centimetres that is 189 up, 311 down and 178 out, so the star is about 500 cm tall.

## Cinema 4D (Justin)

- **Live, editable setup:** open `model/build_star_v02_c4d.py` in Extensions › Script
  Manager and Execute. It builds `Star_v02_live`:
  - A Volume Mesher over a Volume Builder (SDF), which merges three Sweeps:
    `Needle_Y_up`, `Needle_X` and `Needle_Z`.
  - Each Sweep is a 4-sided n-gon (the diamond) along a straight line. The Sweep's
    Details › Scale curve gives the taper.
  - An SDF Smooth filter in the Volume Builder makes the fillets.
  - Things to edit:
    - the Scale curves (taper, point width)
    - the n-gon radius (thickness at the centre)
    - the line points (lengths)
    - SDF Smooth (fillet size)
    - the builder's voxel size (detail)
  - It also merges `star_v02.fbx` as `Star_v02_baked`, hidden. That is the exact mesh the
    renders used, for comparison.
  - It hasn't been run in C4D yet, because the licence on Ravi's Mac had expired. Where
    a parameter ID differs in your version, a dialog lists what to set by hand. The likely
    one is the SDF Smooth filter. The live version gets close to the baked mesh. It won't
    match it exactly, because SDF Smooth rounds everything a little, where the baked mesh
    has true round fillets.
- **Plain import:** `model/star_v02.fbx` (the full mesh, about 940k triangles, Y up in
  C4D, cm). `model/star_v02.usdc` is the 235k-triangle mesh as USD, for C4D 2024+.

## WebGL

- `model/star_v02_web_draco.glb`: about 70k triangles, 170 KB, Draco compressed. In
  three.js, load it with `GLTFLoader` and `DRACOLoader`. It's the one the viewer uses.
- `model/star_v02_mid.glb`: about 235k triangles, 5.6 MB, uncompressed. It loads in any
  glTF viewer (model-viewer, Spline, Babylon).

## Renders (Octane, RTX 3090, 2048 samples, 2400²)

- `renders/studio/`: on the studio gradient.
  - `light_on_dark`: satin porcelain on near black.
  - `dark_on_light`: gloss ink on bone.
- `renders/alpha/`: the same frames on transparent backgrounds, for comping.
- Three cameras:
  - `hero`: the sketch view
  - `low`: eye level, turned
  - `close`: the core

## Source

- `source/star_v02.blend`: the Blender 5.2 scene: the mesh, the cameras (`Cam_Hero` is
  fitted to the sketch), and clay materials.
- The Octane setup (materials, studio lights, kernel; Octane for Blender 31.12) is not a
  separate file: `source/scripts/render_octane.py` builds it onto `star_v02.blend` and
  renders.
- `source/scripts/`: what generated all of it.
  - `diamond.py` and `needles.py`: the shape as a signed distance field, meshed with
    marching cubes. Every number is in `VARIANTS["T1_Short_Stem"]` in `diamond.py`.
  - `fit_camera.py`: solves the camera and the needle lengths from the six tips of the
    drawing.
  - `render_octane.py`, `export_v02.py` and `gen_c4d.py`: the renders, the exports and
    the C4D script.
