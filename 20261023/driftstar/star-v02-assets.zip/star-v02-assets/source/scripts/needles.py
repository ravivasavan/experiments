"""Star v02: three orthogonal needles (X, Y, Z) with a soft mass where they meet.

  uv run --with numpy,scipy,scikit-image python src2/needles.py <out_dir>

Seen from the hero camera (39 deg up, needles turned 45 deg) the object reads as the
flat six-point star of the sketch. Needle lengths and camera come from fit_camera.py.

Each needle half is a round cone (thick at the centre, fine rounded tip). The six halves
and a centre sphere are merged with a smooth minimum, which grows the soft fillets
("mass at the centre") where the needles meet. Polygonised with marching cubes, then
every vertex is projected onto the exact surface.
"""
import json
import sys
from pathlib import Path

import numpy as np
from skimage.measure import marching_cubes

# Lengths in metres (fit to the sketch); Z up. Horizontal needles run along world X and Y.
LEN = dict(top=1.89, bottom=3.11, side=1.78)  # bottom was 3.89 (sketch fit); Ravi: 20% shorter

VARIANTS = {
    # r0: needle radius at the centre; tip: tip radius; taper: horn exponent (higher = flares
    # harder at the centre, finer for longer); core: centre sphere radius; k: blend softness
    "A_Needle": dict(r0=0.20, tip=0.018, taper=2.8, core=0.12, k=0.06),
    "B_Soft": dict(r0=0.26, tip=0.022, taper=2.5, core=0.16, k=0.12),
    "C_Bloom": dict(r0=0.34, tip=0.026, taper=2.3, core=0.22, k=0.2),
}
SEGMENTS = 12  # round cones per needle half: the horn profile, piecewise


def round_cone(p, a, b, r1, r2):
    """Exact SDF of a cone with spherical ends (Inigo Quilez)."""
    ba = b - a
    l2 = ba @ ba
    rr = r1 - r2
    a2 = l2 - rr * rr
    il2 = 1.0 / l2
    pa = p - a
    y = pa @ ba
    z = y - l2
    x2 = ((pa * l2 - y[:, None] * ba) ** 2).sum(1)
    y2, z2 = y * y * l2, z * z * l2
    k = np.sign(rr) * rr * rr * x2
    d = (np.sqrt(np.maximum(x2 * a2 * il2, 0)) + y * rr) * il2 - r1
    end = np.sign(z) * a2 * z2 > k
    start = np.sign(y) * a2 * y2 < k
    d = np.where(start, np.sqrt(x2 + y2) * il2 - r1, d)
    d = np.where(end, np.sqrt(x2 + z2) * il2 - r2, d)
    return d


def round_union(a, b, r):
    """Union with a true round fillet of radius r in the inside corners (no bulge elsewhere)."""
    ua, ub = np.maximum(r - a, 0), np.maximum(r - b, 0)
    return np.maximum(r, np.minimum(a, b)) - np.sqrt(ua * ua + ub * ub)


def smin(a, b, k):
    h = np.maximum(k - np.abs(a - b), 0) / k
    return np.minimum(a, b) - h * h * k * 0.25


def radius(t, v):
    return v["tip"] + (v["r0"] - v["tip"]) * (1 - t) ** v["taper"]


def halves():
    s = LEN["side"]
    return [np.array(d, float) for d in ((0, 0, LEN["top"]), (0, 0, -LEN["bottom"]), (s, 0, 0), (-s, 0, 0), (0, s, 0), (0, -s, 0))]


def needle(p, end, v):
    """One needle half: a horn from the centre to a fine round tip, as a chain of round cones.
    Segments are denser near the centre, where the radius changes fastest."""
    t = np.linspace(0, 1, SEGMENTS + 1) ** 1.6
    d = np.full(len(p), np.inf)
    for t0, t1 in zip(t[:-1], t[1:]):
        d = np.minimum(d, round_cone(p, end * t0, end * t1, radius(t0, v), radius(t1, v)))
    return d


FAR = 1e3


def sdf(p, v):
    """Smooth union of the core and six horns. Each horn is only evaluated inside its own
    bounding box (grown by the blend radius); outside, it is far enough not to change the blend."""
    d = np.linalg.norm(p, axis=1) - v["core"]
    m = v["r0"] + v["k"] + 0.05
    for end in halves():
        lo, hi = np.minimum(end, 0) - m, np.maximum(end, 0) + m
        inb = np.all((p >= lo) & (p <= hi), axis=1)
        dn = np.full(len(p), FAR)
        if inb.any():
            dn[inb] = needle(p[inb], end, v)
        d = smin(d, dn, v["k"])
    return d


def grad(p, v, e=1e-4, f=None):
    f = f or sdf
    g = np.zeros_like(p)
    for i in range(3):
        dp = np.zeros(3)
        dp[i] = e
        g[:, i] = (f(p + dp, v) - f(p - dp, v)) / (2 * e)
    return g


def build(v, h=0.011, f=None, lo=None, hi=None):
    f = f or sdf
    pad = 0.1
    lo = np.array([-LEN["side"] - pad, -LEN["side"] - pad, -LEN["bottom"] - pad]) if lo is None else lo
    hi = np.array([LEN["side"] + pad, LEN["side"] + pad, LEN["top"] + pad]) if hi is None else hi
    n = np.ceil((hi - lo) / h).astype(int) + 1
    xs = [lo[i] + h * np.arange(n[i]) for i in range(3)]
    vol = np.empty(n, np.float32)
    X, Y = np.meshgrid(xs[0], xs[1], indexing="ij")
    for k, z in enumerate(xs[2]):  # slice by slice keeps memory low
        # skip slices far from every needle quickly: still cheap enough to evaluate all
        p = np.c_[X.ravel(), Y.ravel(), np.full(X.size, z)]
        vol[:, :, k] = f(p, v).reshape(X.shape)
    verts, faces, _, _ = marching_cubes(vol, 0.0, spacing=(h, h, h))
    verts += lo
    for _ in range(4):  # newton steps onto the exact zero level
        g = grad(verts, v, f=f)
        verts -= (f(verts, v) / np.maximum((g * g).sum(1), 1e-9))[:, None] * g
    return verts, faces


def write_ply(path, verts, faces):
    with open(path, "wb") as f:
        f.write(f"ply\nformat binary_little_endian 1.0\nelement vertex {len(verts)}\nproperty float x\nproperty float y\nproperty float z\n"
                f"element face {len(faces)}\nproperty list uchar int vertex_indices\nend_header\n".encode())
        f.write(verts.astype("<f4").tobytes())
        fc = np.empty(len(faces), dtype=[("n", "u1"), ("i", "<i4", 3)])
        fc["n"] = 3
        fc["i"] = faces
        f.write(fc.tobytes())


if __name__ == "__main__":
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "out2")
    out.mkdir(parents=True, exist_ok=True)
    pick = list(VARIANTS) if len(sys.argv) < 3 or sys.argv[2] == "all" else sys.argv[2].split(",")
    h = float(sys.argv[3]) if len(sys.argv) > 3 else 0.011
    for name in pick:
        verts, faces = build(VARIANTS[name], h)
        write_ply(out / f"{name}.ply", verts, faces)
        print(name, len(verts), "verts", len(faces), "tris", flush=True)
    (out / "needles_params.json").write_text(json.dumps(dict(LEN=LEN, VARIANTS=VARIANTS), indent=1))
