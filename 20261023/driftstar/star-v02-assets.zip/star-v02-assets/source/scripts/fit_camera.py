"""Fit a perspective camera + needle lengths so three orthogonal needles project onto the sketch's six tips."""
import json, math, sys
import numpy as np
from scipy.optimize import least_squares

# sketch tips (px, centre-relative, y up)
TIPS = np.array([(0, 175), (125, 75), (150, -98), (0, -270), (-150, -98), (-125, 75)], float)

def project(params):
    Ht, Hb, L, elev, D, f, cy = params
    # world: Z up; needles along X, Y (half-length L each end) and Z (Ht up, Hb down)
    # camera at azimuth -90 (looking +Y) then needles rotated 45deg about Z so they read as an X
    c, s = math.cos(math.radians(45)), math.sin(math.radians(45))
    ax = np.array([c, s, 0]); ay = np.array([-s, c, 0])
    P = np.array([Ht * np.array([0, 0, 1]), L * ax, L * -ay, Hb * np.array([0, 0, -1]), L * -ax, L * ay])
    # order matches TIPS: top, upper-right (far +), lower-right (near), stem, lower-left, upper-left
    e = math.radians(elev)
    cam = np.array([0, -D * math.cos(e), D * math.sin(e)])
    fwd = -cam / np.linalg.norm(cam); right = np.array([1, 0, 0]); up = np.cross(right, fwd)
    q = P - cam
    z = q @ fwd
    return np.c_[f * (q @ right) / z, f * (q @ up) / z + cy], z

def resid(p):
    xy, _ = project(p)
    return (xy - TIPS).ravel()

best = least_squares(resid, [2.2, 3.4, 2.0, 30, 12, 1000, 0], bounds=([0.5, 0.5, 0.5, 0, 3, 50, -80], [10, 10, 10, 80, 200, 1e5, 80]))
xy, z = project(best.x)
names = ["Ht", "Hb", "L", "elev_deg", "D", "f", "cy"]
out = dict(zip(names, map(float, best.x)))
out["residual_px"] = np.abs(best.fun).reshape(-1, 2).tolist()
print(json.dumps(out, indent=1))
# equivalent full-frame lens: sketch height ~ 445 px, so sensor 36mm maps to f px over the frame width
