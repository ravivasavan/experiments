"""Write build_star_v02_c4d.py: the star as a live Cinema 4D setup, from the same numbers as the mesh.

  uv run --with numpy python src2/gen_c4d.py <out.py>
"""
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from diamond import VARIANTS, width  # noqa: E402
from needles import LEN  # noqa: E402

v = VARIANTS["T1_Short_Stem"]


def scale_curve(neg, pos, n=40):
    """(t along the whole needle 0..1, scale 0..1) from the -end tip, through the centre, to the +end tip."""
    Ln, Lp = LEN[neg], LEN[pos]
    w0 = max(v[neg][0], v[pos][0])
    pts = []
    for s in np.linspace(-Ln, Lp, n):
        end = pos if s >= 0 else neg
        L = LEN[end]
        Lc = L - v[end][1]
        w = width(np.array([min(abs(s), Lc)]), Lc, v[end], v["bar"])[0]
        pts.append(((s + Ln) / (Ln + Lp), float(w / w0)))
    return dict(len_neg=Ln, len_pos=Lp, w0=w0, knots=[(round(a, 4), round(b, 4)) for a, b in pts])


needles = {
    "Needle_Y_up": dict(axis="Y", **scale_curve("bottom", "top")),  # C4D is Y up: the vertical needle
    "Needle_X": dict(axis="X", **scale_curve("side", "side")),
    "Needle_Z": dict(axis="Z", **scale_curve("side", "side")),
}
params = dict(needles=needles, fillet_cm=v["fillet"] * 100, edge_cm=v["edge"] * 100)

TEMPLATE = r'''"""Cinema 4D: star v02 as a live, nondestructive setup.

Run in C4D 2024+ via Extensions > Script Manager (open this file, Execute). Keep it in the
same folder as star_v02.fbx if you also want the baked reference mesh merged in.

Builds, under one null "Star_v02_live":
  Volume Mesher
    Volume Builder (SDF, union, then an SDF Smooth filter = the soft fillets)
      Needle_Y_up, Needle_X, Needle_Z: each a Sweep of a 4-sided (diamond) profile along a
      straight line, with the Sweep's Scale curve (Details > Scale) giving the taper.
  Star_v02_baked (from FBX, hidden): the exact mesh the renders used, for reference.

Edit live: a Sweep's Scale curve (taper and point width), its profile radius (thickness at
the centre), the line's points (length), the SDF Smooth strength (fillet size), and the
Volume Builder voxel size (detail). Units are cm; the star is ~500 cm tall.

Written for Ravi's star; not yet run in C4D (the licence on Ravi's Mac had expired). Where a
parameter ID differs in your version, the script says what to set by hand.
"""
import json
import os

import c4d

P = json.loads(r"""__PARAMS__""")
HERE = os.path.dirname(__file__) if "__file__" in dir() else ""
S = 100.0  # m -> cm
AX = {"X": c4d.Vector(1, 0, 0), "Y": c4d.Vector(0, 1, 0), "Z": c4d.Vector(0, 0, 1)}
notes = []


def try_set(op, pid_name, value):
    pid = getattr(c4d, pid_name, None)
    if pid is None:
        notes.append(f"{op.GetName()}: set {pid_name} by hand")
        return False
    try:
        op[pid] = value
        return True
    except Exception:
        notes.append(f"{op.GetName()}: set {pid_name} by hand")
        return False


def needle(name, n):
    sw = c4d.BaseObject(c4d.Osweep)
    sw.SetName(name)
    prof = c4d.BaseObject(c4d.Osplinenside)
    prof.SetName(name + "_Diamond")
    prof[c4d.PRIM_NSIDE_SIDES] = 4
    prof[c4d.PRIM_NSIDE_RADIUS] = n["w0"] * S  # corner radius = the diamond's half-diagonal
    a = AX[n["axis"]]
    path = c4d.SplineObject(2, c4d.SPLINETYPE_LINEAR)
    path.SetName(name + "_Path")
    path.SetPoint(0, -a * n["len_neg"] * S)
    path.SetPoint(1, a * n["len_pos"] * S)
    path.Message(c4d.MSG_UPDATE)
    path.InsertUnder(sw)
    prof.InsertUnder(sw)  # the profile must be the first child: inserted last, it lands on top
    sd = c4d.SplineData()
    sd.MakeLinearSplineBezier(len(n["knots"]))
    for i, (t, s) in enumerate(n["knots"]):
        sd.SetKnot(i, c4d.Vector(t, s, 0), c4d.FLAG_KNOT_T_BREAK)
    try_set(sw, "SWEEPOBJECT_SPLINESCALE", sd)
    try_set(sw, "SWEEPOBJECT_CONSTANT", True)  # even cross-section along the rail
    return sw


def main():
    doc = c4d.documents.GetActiveDocument()
    doc.StartUndo()
    root = c4d.BaseObject(c4d.Onull)
    root.SetName("Star_v02_live")
    mesher = c4d.BaseObject(c4d.Ovolumemesher)
    mesher.SetName("Volume Mesher")
    vb = c4d.BaseObject(c4d.Ovolumebuilder)
    vb.SetName("Volume Builder")
    try_set(vb, "ID_VOLUMEBUILDER_VOLUMETYPE", 1)  # 1 = SDF
    try_set(vb, "ID_VOLUMEBUILDER_GRID_SIZE", 0.6)  # voxel size, cm: lower = finer
    sweeps = [needle(k, n) for k, n in P["needles"].items()]
    for sw in reversed(sweeps):
        sw.InsertUnder(vb)
    vb.InsertUnder(mesher)
    mesher.InsertUnder(root)
    doc.InsertObject(root)
    doc.AddUndo(c4d.UNDOTYPE_NEW, root)
    # Children of a Volume Builder join its list as Union. The fillets come from an SDF Smooth
    # filter above them; add it through the API where available, else by hand.
    try:
        sm = c4d.BaseObject(c4d.Osdfsmooth) if hasattr(c4d, "Osdfsmooth") else None
        if sm is not None:
            sm.SetName("SDF Smooth (fillets)")
            sm.InsertUnder(vb)
            try_set(sm, "ID_SDFFILTER_STRENGTH", 100.0)
            try_set(sm, "ID_SDFFILTER_ITERATIONS", 6)
            try_set(sm, "ID_SDFFILTER_VOXEL_DISTANCE", max(1, round(P["fillet_cm"] / 0.6 / 3)))
        else:
            notes.append("Volume Builder: add an SDF Smooth filter above the three sweeps (Filter > SDF Smooth), ~6 iterations")
    except Exception as e:
        notes.append(f"Volume Builder: add an SDF Smooth filter by hand ({e})")
    fbx = os.path.join(HERE, "star_v02.fbx")
    if HERE and os.path.exists(fbx):
        c4d.documents.MergeDocument(doc, fbx, c4d.SCENEFILTER_OBJECTS | c4d.SCENEFILTER_MATERIALS)
        ob = doc.GetFirstObject()
        while ob:
            if ob.GetName() == "Star_v02":  # the merged FBX mesh: keep it as a hidden reference
                ob.SetName("Star_v02_baked")
                ob[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = 1
                ob[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = 1
            ob = ob.GetNext()
    doc.EndUndo()
    c4d.EventAdd()
    if notes:
        c4d.gui.MessageDialog("Star built. A few settings need a hand:\n\n" + "\n".join(notes))


if __name__ == "__main__":
    main()
'''
Path(sys.argv[1]).write_text(TEMPLATE.replace("__PARAMS__", json.dumps(params, indent=1)))
print("wrote", sys.argv[1])
