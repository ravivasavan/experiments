"""Star v02 scene: three needles on the world axes, cameras fitted to the sketch.

  Blender -b --factory-startup -P src2/build_scene.py -- <mesh_dir> <out.blend> [variants]

Cam_Hero is the sketch view: it reads as the flat six-point star. The other cameras
show that it is an object: Cam_Low (eye level, turned), Cam_Close (the core),
Cam_Side, Cam_Top.
"""
import json
import math
import sys
from pathlib import Path

import bpy
from mathutils import Vector

a = sys.argv[sys.argv.index("--") + 1:]
MESH, OUT = Path(a[0]).resolve(), Path(a[1]).resolve()
VARIANTS = a[2].split(",") if len(a) > 2 else ["A_Needle", "B_Soft", "C_Bloom", "D_Facet", "E_Facet_Soft"]

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.unit_settings.system = "METRIC"

# sketch fit (src2/fit_camera.py): elevation 38.98 deg, distance 10.78, f = 1166 sketch px
FIT = dict(elev=38.98, dist=10.78, f_px=1166.0, obj_px=400.0, centre_px=-25.0, origin_px=-3.64)  # bbox with the shorter stem
FILL = 0.78  # fraction of frame height the star fills in Cam_Hero

mat = bpy.data.materials.new("Star_Clay")
mat.use_nodes = True
bsdf = mat.node_tree.nodes["Principled BSDF"]
bsdf.inputs["Base Color"].default_value = (0.8, 0.78, 0.74, 1)
bsdf.inputs["Roughness"].default_value = 0.35

params = {"VARIANTS": {}}
for f in ("needles_params.json", "diamond_params.json"):
    if (MESH / f).exists():
        j = json.loads((MESH / f).read_text())
        params["LEN"] = j["LEN"]
        params["VARIANTS"].update(j["VARIANTS"])
for name in VARIANTS:
    col = bpy.data.collections.new(name)
    sc.collection.children.link(col)
    bpy.ops.wm.ply_import(filepath=str(MESH / f"{name}.ply"))
    ob = bpy.context.selected_objects[0]
    ob.name = ob.data.name = name
    for c in ob.users_collection:
        c.objects.unlink(ob)
    col.objects.link(ob)
    ob.data.shade_smooth()
    ob.data.materials.append(mat)
    for k, v in params["VARIANTS"][name].items():
        ob[k] = v
    for k, v in params["LEN"].items():
        ob[f"len_{k}"] = v

aim = bpy.data.objects.new("Aim", None)
sc.collection.objects.link(aim)


def camera(name, az, elev, dist, lens, shift_y=0.0, target=(0, 0, 0)):
    cd = bpy.data.cameras.new(name)
    cd.lens, cd.sensor_width, cd.sensor_fit = lens, 36, "HORIZONTAL"
    cd.shift_y = shift_y
    cd.clip_end = 200
    ob = bpy.data.objects.new(name, cd)
    sc.collection.objects.link(ob)
    e, z = math.radians(elev), math.radians(az)
    t = Vector(target)
    ob.location = t + Vector((math.sin(z) * math.cos(e), -math.cos(z) * math.cos(e), math.sin(e))) * dist
    ob.rotation_euler = (t - ob.location).to_track_quat("-Z", "Y").to_euler()
    return ob


# Hero: azimuth -45 (between -X and -Y), so the X and Y needles read as the star's diagonals
lens = FIT["f_px"] * FILL * 36 / FIT["obj_px"]
shift = (FIT["centre_px"] - FIT["origin_px"]) * FILL / FIT["obj_px"]
hero = camera("Cam_Hero", -45, FIT["elev"], FIT["dist"], lens, shift)
camera("Cam_Low", -20, 6, 12.0, 60, 0.0, target=(0, 0, -0.6))
camera("Cam_Close", -28, 22, 7.5, 70)
camera("Cam_Side", 0, 0, 22.0, 50, -0.09)
camera("Cam_Top", -45, 89.9, 22.0, 50)
sc.camera = hero
sc.render.resolution_x = sc.render.resolution_y = 2000
bpy.ops.wm.save_as_mainfile(filepath=str(OUT))
print("SAVED", OUT, "lens", round(lens, 2), "shift", round(shift, 4))
