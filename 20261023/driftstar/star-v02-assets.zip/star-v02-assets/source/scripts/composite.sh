#!/usr/bin/env bash
# composite.sh <in_rgba.png> <out.png> <light_on_dark|dark_on_light>: clean radial studio gradient + fine dither
set -euo pipefail
in=$1 out=$2 way=$3
read -r w h < <(magick identify -format "%w %h\n" "$in")
if [[ $way == light_on_dark ]]; then c1='#1b1b1e'; c2='#060607'; else c1='#f1ede7'; c2='#c9c4bc'; fi
magick -size ${w}x${h} -define gradient:center=$((w*42/100)),$((h*36/100)) -define gradient:radii=$((w*85/100)),$((h*85/100)) radial-gradient:"$c1"-"$c2" \
  \( -size ${w}x${h} xc:gray50 +noise Gaussian -channel G -separate +channel -evaluate multiply 0.012 \) -compose plus -composite \
  "$in" -compose over -composite -depth 16 "$out"
