"""Octane studio renders of star v02, three needles (Omarchy, RTX 3090).

  blender-octane.sh -b out2/star_v02.blend -P src2/render_octane.py -- <samples> <res> <variants,...|all> <cams,...|all> <ways,...|all>

Same studio as v01, with the rig turned -45 deg about Z to face Cam_Hero.

Colourways: light_on_dark (satin porcelain on near-black), dark_on_light (gloss
ink on bone). Studio: seamless backdrop, large soft key, rim strip, dim fill.
Saves star_octane.blend (native Octane materials) beside the renders.
"""
import json
import math
import sys
import time
from pathlib import Path

import bpy

ROOT = Path(bpy.data.filepath).resolve().parent.parent
a = sys.argv[sys.argv.index("--") + 1:]
SAMPLES, RES = int(a[0]), int(a[1])
VARIANTS = [c.name for c in bpy.context.scene.collection.children]
CAMS = ["Cam_Hero", "Cam_Low", "Cam_Close"]
WAYS = ["light_on_dark", "dark_on_light"]
pick = lambda s, full: full if s == "all" else s.split(",")
VARIANTS, CAMS, WAYS = pick(a[2], VARIANTS), pick(a[3], CAMS), pick(a[4], WAYS)
OUT = ROOT / ("renders2" if len(a) < 6 else "logs/debug")
HIDE = a[5].split(",") if len(a) > 5 else []
OUT.mkdir(exist_ok=True)

LOOKS = {
    "light_on_dark": dict(
        star=dict(Albedo=(0.82, 0.80, 0.76), Roughness=0.34, Specular=0.5, Coating=0.25, **{"Coating roughness": 0.12, "Sheen": 0.15}),
        backdrop=(0.015, 0.015, 0.017), key=60.0, rim=30.0, fill=0.003, top=8.0, kick=3.0),
    "dark_on_light": dict(
        star=dict(Albedo=(0.018, 0.018, 0.021), Roughness=0.2, Specular=0.6, Coating=1.0, **{"Coating roughness": 0.05}),
        backdrop=(0.80, 0.78, 0.75), key=60.0, rim=30.0, fill=0.01, top=25.0, kick=6.0, glow=0.12),
}

sc = bpy.context.scene
sc.render.engine = "octane"
for vl in sc.view_layers:
    vl.octane.current_preview_pass_type = "0"


def setin(node, name, v):
    s = node.inputs[name]
    try:
        s.default_value = v
    except (TypeError, ValueError):
        s.default_value = (v, v, v) if isinstance(v, float) else v[0]


def mat(name, kind, values, emission=None):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    n = nt.nodes.new(kind)
    for k, v in values.items():
        setin(n, k, v)
    out = nt.nodes.new("OctaneEditorMaterialOutputNode")
    nt.links.new(n.outputs[0], out.inputs["Surface"])
    if emission is not None:
        e = nt.nodes.new("OctaneTextureEmission")
        setin(e, "Power", emission)
        e.inputs["Surface brightness"].default_value = True
        e.inputs["Double sided"].default_value = True
        nt.links.new(e.outputs[0], n.inputs["Emission"])
    return m


def plane(name, size, loc, target=None, rot=None):
    me = bpy.data.meshes.new(name)
    h = size[0] / 2, size[1] / 2
    me.from_pydata([(-h[0], -h[1], 0), (h[0], -h[1], 0), (h[0], h[1], 0), (-h[0], h[1], 0)], [], [(0, 1, 2, 3)])
    ob = bpy.data.objects.new(name, me)
    sc.collection.objects.link(ob)
    ob.location = loc
    if rot:
        ob.rotation_euler = rot
    if target is not None:
        c = ob.constraints.new("TRACK_TO")
        c.target, c.track_axis, c.up_axis = target, "TRACK_Z", "UP_Y"
    return ob


aim = bpy.data.objects.new("Aim", None)
sc.collection.objects.link(aim)
aim.location = (0, 0, -0.3)
HERO_AZ = -45.0  # every light is placed relative to Cam_Hero's azimuth


def around(az_rel, elev, dist):
    """Point on a sphere about the aim, azimuth measured from Cam_Hero's (0 = behind the camera)."""
    az, e = math.radians(HERO_AZ + az_rel), math.radians(elev)
    return (math.sin(az) * math.cos(e) * dist, -math.cos(az) * math.cos(e) * dist + 0, math.sin(e) * dist - 0.3)


backdrop = plane("Backdrop", (60, 60), around(180, 0, 4.0), target=aim)
backdrop.octane.camera_visibility = False  # still bounces + reflects; the background is composited clean
key = plane("Key_Softbox", (4.5, 5.5), around(-70, 40, 9.0), target=aim)   # camera left, high
rim = plane("Rim_Strip", (0.8, 8), around(140, 22, 8.0), target=aim)       # behind, right: edge light
top = plane("Top_Strip", (7, 0.8), around(175, 72, 9.0), target=aim)       # behind, overhead: top edges
kick = plane("Kick_Strip", (1.0, 6), around(75, 8, 9.0), target=aim)       # camera right, low
flag = plane("Flag", (6, 6), around(110, 12, 6.5), target=aim)             # black card, camera right: dark reflections
for l in (key, rim, top, kick, flag):
    l.octane.camera_visibility = False
    l.octane.shadow_visibility = False


kg = bpy.data.node_groups.new("Star path tracing", "octane_kernel_nodes")
kernel = kg.nodes.new("OctanePathTracingKernel")
kout = kg.nodes.new("OctaneKernelOutputNode")
kg.links.new(kernel.outputs[0], kout.inputs["Kernel"])
kernel.inputs["Max. samples"].default_value = SAMPLES
for name in ("Alpha channel",):
    if name in kernel.inputs:
        kernel.inputs[name].default_value = True
        print("ALPHA_ON", flush=True)
for name, v in [("Diffuse depth", 6), ("Specular depth", 16), ("Scatter depth", 8)]:
    kernel.inputs[name].default_value = v
sc.octane.kernel_data_mode = "NODETREE"
sc.octane.kernel_node_graph_property.node_tree = kg
sc.octane.max_samples = SAMPLES
sc.octane.use_render_camera_imager = True
sc.octane.use_preview_setting_for_camera_imager = False
for cname in CAMS:
    im = bpy.data.objects[cname].data.octane.imager
    im.denoiser = True
    im.denoiser_type = "Octane AI denoiser"
    im.denoise_once = True
    im.min_denoise_samples = 16
    if "EXPOSURE" in __import__("os").environ:
        im.exposure = float(__import__("os").environ["EXPOSURE"])
    print("IMAGER", cname, {k: getattr(im, k) for k in ("exposure", "highlight_compression", "white_saturation", "max_tonemap_interval") if hasattr(im, k)}, flush=True)
sc.camera = bpy.data.objects[CAMS[0]]
for vl in sc.view_layers:
    vl.octane.render_pass_style = "RENDER_PASSES"
    vl.octane.use_pass_denoise_beauty = True
    vl.update_render_passes()
comp = bpy.data.node_groups.new("Denoised beauty", "CompositorNodeTree")
comp.interface.new_socket(name="Image", in_out="OUTPUT", socket_type="NodeSocketColor")
rl = comp.nodes.new("CompositorNodeRLayers")
rl.scene = sc
print("RL_OUTPUTS", [o.name for o in rl.outputs if o.enabled], flush=True)
go = comp.nodes.new("NodeGroupOutput")
comp.links.new(rl.outputs["DenoisedBeauty"], go.inputs["Image"])
sc.compositing_node_group = comp
sc.render.use_compositing = True
sc.render.resolution_x = sc.render.resolution_y = RES
sc.view_settings.view_transform = "Standard"
sc.view_settings.look = "Medium Contrast"
sc.render.resolution_percentage = 100
sc.render.image_settings.file_format = "PNG"
sc.render.image_settings.color_depth = "16"
sc.render.image_settings.color_mode = "RGBA"
sc.render.film_transparent = True


world = bpy.data.worlds.new("Star fill")
sc.world = world
world.use_nodes = True
world.node_tree.nodes.clear()
env = world.node_tree.nodes.new("OctaneTextureEnvironment")
wo = world.node_tree.nodes.new("OctaneEditorWorldOutputNode")
world.node_tree.links.new(env.outputs[0], wo.inputs["Environment"])

report = []
for n in HIDE:
    if n in bpy.data.objects:
        bpy.data.objects[n].hide_render = True
for way in WAYS:
    L = LOOKS[way]
    star_m = mat(f"Star_{way}", "OctaneUniversalMaterial", L["star"])
    backdrop.data.materials.clear()
    backdrop.data.materials.append(mat(f"Backdrop_{way}", "OctaneDiffuseMaterial", {"Diffuse": L["backdrop"], "Roughness": 1.0}, emission=L.get("glow")))
    for l, p in ((key, L["key"]), (rim, L["rim"]), (top, L["top"]), (kick, L["kick"])):
        l.data.materials.clear()
        l.data.materials.append(mat(f"{l.name}_{way}", "OctaneDiffuseMaterial", {"Diffuse": (0, 0, 0)}, emission=p))
    flag.data.materials.clear()
    flag.data.materials.append(mat("Flag_black", "OctaneDiffuseMaterial", {"Diffuse": (0.002, 0.002, 0.002), "Roughness": 1.0}))
    setin(env, "Power", L["fill"])
    for v in VARIANTS:
        ob = bpy.data.objects[v]
        ob.data.materials.clear()
        ob.data.materials.append(star_m)
        for c in VARIANTS:
            bpy.data.collections[c].hide_render = c != v
        for cname in CAMS:
            sc.camera = bpy.data.objects[cname]
            out = OUT / f"{v}__{way}__{cname.replace('Cam_', '').lower()}.png"
            sc.render.filepath = str(out)
            t = time.time()
            bpy.ops.render.render(write_still=True)
            report.append(dict(variant=v, way=way, cam=cname, samples=SAMPLES, res=RES, seconds=round(time.time() - t, 1), file=out.name))
            print("RENDERED", json.dumps(report[-1]), flush=True)

bpy.ops.wm.save_as_mainfile(filepath=str(ROOT / "out2" / "star_v02_octane.blend"), copy=True)
(OUT / f"report_{int(time.time())}.json").write_text(json.dumps(report, indent=2))
print("ALL_DONE", len(report), flush=True)
