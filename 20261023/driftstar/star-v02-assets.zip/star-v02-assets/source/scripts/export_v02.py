"""Export star v02 for C4D and WebGL.

  Blender -b out2/star_v02.blend -P src2/export_v02.py -- <out_dir>

  star_v02.fbx                   full mesh (~940k tris): Cinema 4D, Octane, any DCC
  star_v02_mid.glb / .usdc       ~235k tris: plain glTF (model-viewer, Spline, Babylon) and USD
  star_v02_web_draco.glb         ~70k tris, Draco: the three.js viewer
Units: metres, Z up in Blender; glTF is written Y up as the spec wants.
"""
import json
import sys
from pathlib import Path

import bpy

out = Path(sys.argv[sys.argv.index("--") + 1])
out.mkdir(parents=True, exist_ok=True)
src = bpy.data.objects["Star_v02"]


def select(ob):
    bpy.ops.object.select_all(action="DESELECT")
    ob.hide_set(False)
    ob.select_set(True)
    bpy.context.view_layer.objects.active = ob


def decimated(ratio, name):
    ob = src.copy()
    ob.data = src.data.copy()
    ob.name = ob.data.name = name
    src.users_collection[0].objects.link(ob)
    m = ob.modifiers.new("Decimate", "DECIMATE")
    m.ratio = ratio
    return ob


select(src)
bpy.ops.export_scene.fbx(filepath=str(out / "star_v02.fbx"), use_selection=True, apply_scale_options="FBX_SCALE_ALL")

mid = decimated(0.25, "Star_v02_mid")
select(mid)
bpy.ops.export_scene.gltf(filepath=str(out / "star_v02_mid.glb"), use_selection=True, export_apply=True, export_yup=True)
bpy.ops.wm.usd_export(filepath=str(out / "star_v02.usdc"), selected_objects_only=True, export_materials=True)

web = decimated(0.075, "Star_v02_web")
select(web)
bpy.ops.export_scene.gltf(filepath=str(out / "star_v02_web_draco.glb"), use_selection=True, export_apply=True, export_yup=True,
                          export_draco_mesh_compression_enable=True, export_draco_mesh_compression_level=7,
                          export_draco_position_quantization=16, export_draco_normal_quantization=12)
print("EXPORT_OK", json.dumps({p.name: round(p.stat().st_size / 1e6, 2) for p in sorted(out.iterdir())}))
