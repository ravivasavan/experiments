"""Star v02, faceted family: three diamond-section needles on the world axes.

  uv run --with numpy,scipy,scikit-image python src2/diamond.py <out_dir> [variants|all] [voxel]

Each needle is a diamond (a square turned 45 deg, corners pointing along the other two
axes) swept along its axis. Near the centre it keeps its full width, so the three cross
as square bars and the core comes out as a soft octahedron. Further out the sides curve
in (concave) to a fine point. Edges are rounded a little, and the three bars are merged
with a smooth minimum so the inside corners get soft fillets.
"""
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from needles import LEN, build, write_ply  # noqa: E402

# Per needle: (w0 half-diagonal at the centre, tip half-diagonal, taper: 1 straight, higher =
# sides curve in harder). bar: half-length kept at full width; edge: edge rounding;
# fillet: radius of the round fillet sweeping each needle into its neighbours.
# dist "l1" keeps the diamond's corners sharp in the fillets, so its ridges run on through the
# webs (the faceted look); "euclid" rounds them away. union "pair" merges the needles one
# after another (ridge where the fillets meet), "all" merges them in one go.
BASE = dict(top=(0.20, 0.012, 2.6), side=(0.20, 0.012, 2.6), bottom=(0.20, 0.012, 2.6),
            bar=0.10, edge=0.012, fillet=0.30, dist="l1", union="pair")
# R1 (Full points) as picked, then: points 1.5x thicker, ridges softened (ridge = rounding width)
R1 = dict(BASE, top=(0.20, 0.03, 2.0), side=(0.20, 0.032, 2.0), bottom=(0.20, 0.04, 2.4))
R1T = dict(R1, top=(0.20, 0.045, 2.0), side=(0.20, 0.048, 2.0), bottom=(0.20, 0.06, 2.4))
VARIANTS = {
    "R1_Full_Points": R1,
    "S1_Ridge_Soft": dict(R1T, soften=0.3, edge=0.016),
    "T1_Short_Stem": dict(R1T, soften=0.3, edge=0.016),  # S1 with the stem 20% shorter (LEN)
    "S2_Ridge_Softer": dict(R1T, soften=0.55, edge=0.02),
    "S3_Ridge_Softest": dict(R1T, soften=0.8, edge=0.024),
}

AXES = [  # (axis, cross-section axes, (+axis half, -axis half))
    (np.array([0, 0, 1.0]), np.array([1, 0, 0.0]), np.array([0, 1, 0.0]), ("top", "bottom")),
    (np.array([1, 0, 0.0]), np.array([0, 1, 0.0]), np.array([0, 0, 1.0]), ("side", "side")),
    (np.array([0, 1, 0.0]), np.array([0, 0, 1.0]), np.array([1, 0, 0.0]), ("side", "side")),
]


def width(s, L, prof, bar):
    """Half-diagonal along one needle half: flat over the bar, then a concave taper to the tip."""
    w0, tip, taper = prof
    t = np.clip((s - bar) / (L - bar), 0, 1)
    return tip + (w0 - tip) * (1 - t) ** taper


def needle(p, ax, e1, e2, ends, v):
    s = p @ ax
    pos = s >= 0
    L = np.where(pos, LEN[ends[0]], LEN[ends[1]])
    tip = np.where(pos, v[ends[0]][1], v[ends[1]][1])
    Lc = L - tip  # the taper stops one tip-width short; a round cap closes the last stretch
    sa = np.abs(s)
    sc = np.minimum(sa, Lc)
    w = np.where(pos, width(sc, Lc, v[ends[0]], v["bar"]), width(sc, Lc, v[ends[1]], v["bar"]))
    w = np.maximum(w - v["edge"] * np.sqrt(2), 1e-4)  # shrink, then round by offset (below)
    u, t = p @ e1, p @ e2
    # Cross-section field. l1: the diamond's corners stay sharp in the field around it, so
    # its ridges run on through the fillets. euclid: the field rounds them off. `soften`
    # blends the two (0 sharp ridges, 1 none); the needles themselves are the same either way.
    sec = (np.abs(u) + np.abs(t) - w) / np.sqrt(2)
    k = v.get("soften", 0.0 if v.get("dist") == "l1" else 1.0)
    if k > 0:
        qa = np.abs(u + t) / np.sqrt(2) - w / np.sqrt(2)
        qb = np.abs(u - t) / np.sqrt(2) - w / np.sqrt(2)
        eu = np.sqrt(np.maximum(qa, 0) ** 2 + np.maximum(qb, 0) ** 2) + np.minimum(np.maximum(qa, qb), 0)
        sec = (1 - k) * sec + k * eu
    # Past Lc the needle closes in a dome built from that same section field (revolved
    # about a radius R), so dome and shaft agree exactly where they meet: no step, no bead.
    R = w / np.sqrt(2)
    a = np.maximum(sa - Lc, 0)
    dome = np.sqrt(np.maximum(sec + R, 0) ** 2 + a * a) - R
    return np.where(sa > Lc, dome, sec) - v["edge"]


def round_union(a, b, r):
    ua, ub = np.maximum(r - a, 0), np.maximum(r - b, 0)
    return np.maximum(r, np.minimum(a, b)) - np.sqrt(ua * ua + ub * ub)


def sdf(p, v):
    ds = [needle(p, ax, e1, e2, ends, v) for ax, e1, e2, ends in AXES]
    r = v["fillet"]
    if v.get("union") == "pair":
        d = ds[0]
        for dn in ds[1:]:
            d = round_union(d, dn, r)
        return d
    u = sum(np.maximum(r - d, 0) ** 2 for d in ds)
    return np.maximum(r, np.minimum.reduce(ds)) - np.sqrt(u)


if __name__ == "__main__":
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "out2/mesh")
    out.mkdir(parents=True, exist_ok=True)
    pick = list(VARIANTS) if len(sys.argv) < 3 or sys.argv[2] == "all" else sys.argv[2].split(",")
    h = float(sys.argv[3]) if len(sys.argv) > 3 else 0.008
    for name in pick:
        verts, faces = build(VARIANTS[name], h, f=sdf)
        write_ply(out / f"{name}.ply", verts, faces)
        print(name, len(verts), "verts", len(faces), "tris", flush=True)
    (out / "diamond_params.json").write_text(json.dumps(dict(LEN=LEN, VARIANTS=VARIANTS), indent=1))
